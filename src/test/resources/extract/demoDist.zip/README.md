#buildSrc
Very basic collection of buildSrc code.